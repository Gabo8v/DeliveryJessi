# Comida Mecha — Brand spec

## Colors

| Token | Hex | Role |
|---|---|---|
| `--bg` | #FDF3E7 | Fondo crema suave |
| `--surface` | #FFFFFF | Tarjetas, inputs |
| `--fg` | #3D2C2E | Texto principal |
| `--muted` | #8C7A7B | Texto secundario |
| `--border` | #E0D5C7 | Bordes de inputs |
| `--primary` | #E8895F | Naranja terracota (botones, acciones) |
| `--secondary` | #7A9E7F | Verde oliva (secondary UI) |
| `--accent` | #C4A484 | Marrón claro (detalles) |
| `--danger` | #D96C6C | Errores, deudas |
| `--success` | #7A9E7F | Pagado, al día |

- **Prohibido**: cualquier variante de azul en la UI.
- **Sombra**: `0 2px 12px rgba(61, 44, 46, 0.08)` sobre tarjetas.

## Tipografía

- **Familia**: `system-ui, -apple-system, sans-serif`
- **Base**: 16px
- **Botones**: min-height 48px
- **Inputs**: border-radius 10px, padding 14px, fondo blanco

## Layout

- Padding lateral: 16px
- Tarjetas: border-radius 16px, padding 16px, gap 12px
- Transiciones: 0.2s ease
- Solo modo claro

## Iconografía

Usar emojis como íconos de navegación (definido por el brief):
`🏠 📋 👥 📊 ⚙️`

